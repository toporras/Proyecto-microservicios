package com.example.jugador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@EnableFeignClients
@SpringBootApplication
public class JugadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(JugadorApplication.class, args);
	}

}
